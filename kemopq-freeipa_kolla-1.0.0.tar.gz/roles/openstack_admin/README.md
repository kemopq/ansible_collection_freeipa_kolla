# kemopq.freeipa_kolla.openstack_admin role
Role for creating domains connected to IPA directory, default projects and
associated user groups.
