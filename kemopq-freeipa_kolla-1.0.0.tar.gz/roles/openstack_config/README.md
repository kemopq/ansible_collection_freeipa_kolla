# kemopq.freeipa_kolla.openstack_config role
Role for preparing Keystone and Horizon configuration files.
