# kemopq.freeipa_kolla.ipa_config role
Role for creating default users and groups (defined in config file) in IPA directory.
